© Cypress Semiconductor Corporation, 2017. This document is the property of Cypress Semiconductor Corporation and its
subsidiaries, including Spansion LLC (“Cypress”).  This document, including any software or firmware included or referenced in this
document (“Software”), is owned by Cypress under the intellectual property laws and treaties of the United States and other countries
worldwide.  Cypress reserves all rights under such laws and treaties and does not, except as specifically stated in this paragraph, grant
any license under its patents, copyrights, trademarks, or other intellectual property rights.  If the Software is not accompanied by a
license agreement and you do not otherwise have a written agreement with Cypress governing the use of the Software, then Cypress
hereby grants you a personal, non-exclusive, nontransferable license (without the right to sublicense) (1) under its copyright rights in
the Software (a) for Software provided in source code form, to modify and reproduce the Software solely for use with Cypress hardware
products, only internally within your organization, and (b) to distribute the Software in binary code form externally to end users (either
directly or indirectly through resellers and distributors), solely for use on Cypress hardware product units, and (2) under those claims of
Cypress’s patents that are infringed by the Software (as provided by Cypress, unmodified) to make, use, distribute, and import the
Software solely for use with Cypress hardware products.  Any other use, reproduction, modification, translation, or compilation of the
Software is prohibited. 
TO THE EXTENT PERMITTED BY APPLICABLE LAW, CYPRESS MAKES NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
WITH REGARD TO THIS DOCUMENT OR ANY SOFTWARE OR ACCOMPANYING HARDWARE, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. To the extent permitted
by applicable law, Cypress reserves the right to make changes to this document without further notice. Cypress does not assume any
liability arising out of the application or use of any product or circuit described in this document.  Any information provided in this
document, including any sample design information or programming code, is provided only for reference purposes.  It is the
responsibility of the user of this document to properly design, program, and test the functionality and safety of any application made of
this information and any resulting product.  Cypress products are not designed, intended, or authorized for use as critical components in
systems designed or intended for the operation of weapons, weapons systems, nuclear installations, life-support devices or systems, 
other medical devices or systems (including resuscitation equipment and surgical implants), pollution control or hazardous substances
management, or other uses where the failure of the device or system could cause personal injury, death, or property damage
(“Unintended Uses”).  A critical component is any component of a device or system whose failure to perform can be reasonably
expected to cause the failure of the device or system, or to affect its safety or effectiveness.  Cypress is not liable, in whole or in part,
and you shall and hereby do release Cypress from any claim, damage, or other liability arising from or related to all Unintended Uses of
Cypress products.  You shall indemnify and hold Cypress harmless from and against all claims, costs, damages, and other liabilities,
including claims for personal injury or death, arising from or related to any Unintended Uses of Cypress products. 
Cypress, the Cypress logo, Spansion, the Spansion logo, and combinations thereof, WICED, PSoC, CapSense, EZ-USB, F-RAM, and
Traveo are trademarks or registered trademarks of Cypress in the United States and other countries.  For a more complete list of
Cypress trademarks, visit cypress.com.  Other names and brands may be claimed as property of their respective owners. 
 

Cypress KitProg3 Firmware(FW) Loader
-----------------------------------

The FW Loader: 
- provides the capability to upgrade the KitProg3 and DAPLink custom application on Cypress kits
- allows updating/switching the KitProg FW from KitProg2 to KitProg3.

It is a command-line tool to be run from a terminal application. 

Command-line Options

No arguments, --help or /? – Displays the list of supported commands with their descriptions.

--device-list – Displays the list of connected devices.

--update-kp3 [device-name] – updates FW of the device with a specified name to KitProg3.
    The device name is taken from the "--device-list" command.
    The device name can be skipped only if one KitProg device is connected to the PC.

--update-kp2 [device-name] – updates FW of the device with a specified name to KitProg2
    The device name is taken from the "--device-list" command.
    The device name can be skipped only if one KitProg device is connected to the PC.

    
Notes 
1.  KitProg2 supports two modes: CMSIS-DAP and KitProg2 Proprietary. Only the KitProg2 
    Proprietary mode supports the bootloader and therefore only in this mode KitProg2 is visible 
    by the FW loader. Use the Mode Switch button to switch KitProg2 to Proprietary mode.

2.  KitProg3 supports two modes: CMSIS-DAP BULK and CMSIS-DAP HID. Also, it implements DapLink as a custom application. 
    Only the KitProg3 modes support the bootloader and therefore only in these modes KitProg3 is visible 
    by the FW loader. Use the Custom App Switch button to switch between KitProg3 and Custom App modes.
    
3.  MiniProg4 does not support the KitProg2 FW. 
    The following symptoms show that KitProg2 FW is uploaded to MiniProg4:
    - The device is detected as MiniProg4 but doesn't operate.
    - Errors are observed while performing the "--device-list" command:
        - Error =  Timeout of Response read for '0x90' command. Num attempts = '2'
        - Error =  Out Endpoint is not found

    If the KitProg2 FW is uploaded to MiniProg4, do the following steps to restore the device functionality:
        1. Switch the device to Bootloader mode:
            - unplug MiniProg4 from the USB
            - press the Mode Switch button (SW1)
            - plug in a USB cable with a pressed button
            - LED1's blinking monitors Bootloader mode
            - release the button.
        2. Perform the "--update-kp3" command as described above.
    
4.  Run the udev_rules\install_rules.sh script on the Linux machine before the first run 
    of the FW loader.